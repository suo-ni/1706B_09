import axios from '../utils/request'

//轮播图
export let getBanner = () => {
    return axios.get('/')
}

//图标
export let getChannel = () => {
    return axios.get('/')
}