import axios from '../utils/request'

//轮播图
export let getBanner = () => {
    return axios.get('/')
}

//图标
export let getChannel = () => {
    return axios.get('/')
}

//品牌制造商

export let getNewGoodsList = () => {
    return axios.get('/')
}

//新品首发
export let getBrandList = () => {
    return axios.get('/')
}

//人气推荐
export let gethotGoodsList = () => {
    return axios.get('/')
}

//专题精选
export let gettopicList= () => {
    return axios.get('/')
}

//居家
export let getcategoryList = () => {
    return axios.get('/')
}

//居家餐厨什么的
export let getgoodsList = () => {
    return axios.get('/')
}