import React from 'react'
import { PropType, RouterItemType } from '../../utils/interface'

let TopicDetailPage: React.FC<PropType> = props=>{
    return null;
}

export default TopicDetailPage;