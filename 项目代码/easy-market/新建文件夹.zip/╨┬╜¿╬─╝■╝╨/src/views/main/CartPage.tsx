import React from 'react'
import { PropType, RouterItemType } from '../../utils/interface'

let CartPage: React.FC<PropType> = props=>{
    return null;
}

export default CartPage;