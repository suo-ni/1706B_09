import React from 'react';


interface PropsType {
  totalPrice: number,
  totalNum: number
}

let Footer: React.FC<PropsType> = props =>{
  return <div>
      
    </div>;

  
}

export default Footer;